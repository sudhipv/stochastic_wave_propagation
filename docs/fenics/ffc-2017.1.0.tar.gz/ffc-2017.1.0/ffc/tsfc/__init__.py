from ffc.tsfc.tsfcrepresentation import compute_integral_ir
from ffc.tsfc.tsfcoptimization import optimize_integral_ir
from ffc.tsfc.tsfcgenerator import generate_integral_code
