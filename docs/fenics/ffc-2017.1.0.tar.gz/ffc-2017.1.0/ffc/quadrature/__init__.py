# -*- coding: utf-8 -*-
from ffc.quadrature.quadraturerepresentation import compute_integral_ir
from ffc.quadrature.quadratureoptimization import optimize_integral_ir
from ffc.quadrature.quadraturegenerator import generate_integral_code
