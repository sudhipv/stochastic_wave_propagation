.. title:: User manual


===========
User manual
===========

.. note:: This page is work in progress.
