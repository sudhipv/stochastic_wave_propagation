.. title:: User manual


===========
User manual
===========

The commandline tool 'dijitso' is currently only documented on the
commandline, run 'dijitso --help' for details and available subcommands.

The python module dijitso is only used internally by ffc,
and no manual has been written so far. See API reference.
