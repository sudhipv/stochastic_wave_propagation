#!/bin/bash
rm -rf report*.xml htmlcov* output.* *.pyc *~ *.dst .test_* .coverage .dijitso .cache
