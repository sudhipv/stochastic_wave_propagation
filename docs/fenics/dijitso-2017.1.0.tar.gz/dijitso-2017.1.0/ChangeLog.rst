Changelog
=========

2017.1.0 (2017-05-09)
---------------------

- Minor fixes

2016.2.0 (2016-11-30)
---------------------

- Introduce commandline script ``dijitso`` with various subcommands to
  interact with the cache
- Improve extraction of source files to reproduce compilation failure
  during jit
- Implement support for linking between jit modules
- Add optional dependency on ``subprocess32`` to handle fork safety on
  infiniband clusters
- Remove ``instant`` dependency

2016.1.0 (2016-06-23)
---------------------

- Initial implementation
