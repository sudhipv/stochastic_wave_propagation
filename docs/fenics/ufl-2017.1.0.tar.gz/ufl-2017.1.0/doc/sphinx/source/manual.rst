.. title:: User manual


===========
User manual
===========

.. toctree::
   :maxdepth: 1

   manual/introduction
   manual/form_language
   manual/examples
   manual/internal_representation
   manual/algorithms
   manual/command_line_utils
