# -*- coding: utf-8 -*-
# Moved here to be usable in ufl.* files without depending on
# ufl.algorithms.*...

from ufl.corealg.multifunction import MultiFunction # flake8: noqa
