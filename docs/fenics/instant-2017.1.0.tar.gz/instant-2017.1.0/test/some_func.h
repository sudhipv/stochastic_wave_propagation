
#include <math.h>

double some_func(double a) {
  return cos(a) + sin(a); 
}


