#!/usr/bin/env python

from __future__ import print_function
import pytest

print("Not cleaning local test cache before tests.")
pytest.main()
