.. title:: Release notes


=============
Release notes
=============

.. toctree::
   :maxdepth: 2

   releases/next
   releases/v2017.1.0
   releases/v2016.2.0
   releases/v2016.1.0
   releases/v1.6.0
